Please run the program in the terminal. I have properly asked about what to input and what you want to do with the program. Please input accordingly in the terminal as per the instructions printed out by my program.
Thank you.

Q1

To compile:
gcc .\q1.c

To execute:
.\a.exe 


Q2

To compile:
gcc .\q2.c

To execute:
.\a.exe