Please give the input to the vertices in this format.
0 4
1 0
1 5
2 1
2 5
3 6
3 7
4 1
5 4
6 2
6 5
7 6
7 3
-1 -1

-1 -1 is given to terminate the inputs.

Input 
1 for directed graph
0 for undirected graph

To compile : gcc .\problem1.c
To execute: \a.exe 