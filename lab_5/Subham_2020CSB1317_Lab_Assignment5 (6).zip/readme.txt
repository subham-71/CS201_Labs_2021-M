To compile: gcc .\problem1.c
To execute: .\a.exe


For the A part: 
If t>=10 , then only such a BTree is possible to hold values from 1 to 100. So please enter a 
value above or equal to 10 to test the 'A' input part.