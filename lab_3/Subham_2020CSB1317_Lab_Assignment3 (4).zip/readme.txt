We can directly use the DetectCycle and the DetectFindStart funtions by simply passing the
head of the linked list of which we want to test the cycle questions(detect cycle,cycle length,distance from head).

To compile the file: gcc .\problem1.c
To execute it : .\a.exe 
