Please give the input to the vertices in this format.
0 1
0 4
1 5
2 3
2 5
2 6
3 6
3 7
5 6
6 7
-1 -1

-1 -1 is given to terminate the inputs.

Input 
1 for directed graph
0 for undirected graph

To compile : gcc .\problem1.c
To execute: \a.exe  

