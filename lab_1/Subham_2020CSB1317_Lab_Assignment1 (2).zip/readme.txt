To compile a file with name "q1.c" :
gcc .\q1.c

Then for execution:
.\a.exe