To compile: gcc .\problem1.c
To execute: .\a.exe