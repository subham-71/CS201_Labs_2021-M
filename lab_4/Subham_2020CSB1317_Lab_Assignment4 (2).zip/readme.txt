PROBLEM 1
To compile the file: gcc .\problem1.c
To execute it : .\a.exe 


PROBLEM 2
To compile the file: gcc .\problem2.c
To execute it : .\a.exe 
